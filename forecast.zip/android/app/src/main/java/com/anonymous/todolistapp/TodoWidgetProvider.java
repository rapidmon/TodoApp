// android/app/src/main/java/com/todolistapp/TodoWidgetProvider.java
package com.todolistapp;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class TodoWidgetProvider extends AppWidgetProvider {
    
    private static final String PREFS_NAME = "TodoWidgetPrefs";
    private static final String TODOS_KEY = "todos";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.todo_widget);
        
        // 위젯 제목 설정
        views.setTextViewText(R.id.widget_title, "할 일 목록");
        
        // 할 일 데이터 로드
        JSONArray todos = loadTodos(context);
        
        // 위젯에 할 일 목록 표시 (최대 20개)
        displayTodos(context, views, todos);
        
        // 앱 실행 인텐트 설정
        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_container, pendingIntent);
        
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }
    
    private static JSONArray loadTodos(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String todosJson = prefs.getString(TODOS_KEY, "[]");
        try {
            return new JSONArray(todosJson);
        } catch (Exception e) {
            return new JSONArray();
        }
    }
    
    private static void displayTodos(Context context, RemoteViews views, JSONArray todos) {
        // 기존 아이템들 숨기기
        int[] todoIds = {
            R.id.todo_item_1, R.id.todo_item_2, R.id.todo_item_3, R.id.todo_item_4, R.id.todo_item_5,
            R.id.todo_item_6, R.id.todo_item_7, R.id.todo_item_8, R.id.todo_item_9, R.id.todo_item_10
        };
        
        int[] titleIds = {
            R.id.todo_title_1, R.id.todo_title_2, R.id.todo_title_3, R.id.todo_title_4, R.id.todo_title_5,
            R.id.todo_title_6, R.id.todo_title_7, R.id.todo_title_8, R.id.todo_title_9, R.id.todo_title_10
        };
        
        int[] progressIds = {
            R.id.todo_progress_1, R.id.todo_progress_2, R.id.todo_progress_3, R.id.todo_progress_4, R.id.todo_progress_5,
            R.id.todo_progress_6, R.id.todo_progress_7, R.id.todo_progress_8, R.id.todo_progress_9, R.id.todo_progress_10
        };
        
        // 모든 아이템 숨기기
        for (int i = 0; i < todoIds.length; i++) {
            views.setViewVisibility(todoIds[i], RemoteViews.GONE);
        }
        
        // 할 일 표시 (최대 10개, 완료되지 않은 것만)
        int displayCount = 0;
        for (int i = 0; i < todos.length() && displayCount < 10; i++) {
            try {
                JSONObject todo = todos.getJSONObject(i);
                if (!todo.getBoolean("completed")) {
                    String title = todo.getString("title");
                    int timeLeft = todo.getInt("timeLeft");
                    
                    // 제목 길이 제한 (10글자)
                    if (title.length() > 10) {
                        title = title.substring(0, 10) + "...";
                    }
                    
                    // 아이템 보이기
                    views.setViewVisibility(todoIds[displayCount], RemoteViews.VISIBLE);
                    views.setTextViewText(titleIds[displayCount], title);
                    
                    // 프로그레스 바 설정 (21일 기준)
                    int progress = Math.max(0, Math.min(timeLeft, 21)) * 100 / 21;
                    views.setProgressBar(progressIds[displayCount], 100, progress, false);
                    
                    // 클릭 이벤트 설정
                    Intent clickIntent = new Intent(context, MainActivity.class);
                    clickIntent.putExtra("todoId", todo.getString("id"));
                    PendingIntent clickPendingIntent = PendingIntent.getActivity(
                        context, 
                        displayCount, 
                        clickIntent, 
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    );
                    views.setOnClickPendingIntent(todoIds[displayCount], clickPendingIntent);
                    
                    displayCount++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        // 할 일이 없을 때 메시지 표시
        if (displayCount == 0) {
            views.setViewVisibility(R.id.empty_message, RemoteViews.VISIBLE);
            views.setTextViewText(R.id.empty_message, "할 일이 없습니다");
        } else {
            views.setViewVisibility(R.id.empty_message, RemoteViews.GONE);
        }
    }
    
    public static void updateWidgetData(Context context, JSONArray todos) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(TODOS_KEY, todos.toString());
        editor.apply();
        
        // 위젯 업데이트
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(new android.content.ComponentName(context, TodoWidgetProvider.class));
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }
}